class Window {
	public:
		char framebuffer[70][70];
		Window() {};
};
