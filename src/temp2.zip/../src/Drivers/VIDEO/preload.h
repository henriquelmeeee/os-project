#ifndef PRELOAD_VIDEO
#define PRELOAD_VIDEO
#define RES_WIDTH 800
#define RES_HEIGHT 600
struct FrameBuffer {
  char a; // TODO
};
#include "Video.h"
#endif
