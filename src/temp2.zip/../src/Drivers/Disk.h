void write_to_sector(short* bytes, unsigned int sector);
void read_from_sector(char* buffer, unsigned int sector);
