#include "Tasks/Process.h"
#include "Utils/Base.h"

void quantum_interruption_handle() {
  unsigned long long cpu_cycles_used;
  __asm__ volatile(
    "rtscp"
    : "=A" (cpu_cycles_used));
  proc_current->cycles_finished = ( proc_current->cycles_started ) - ( cpu_cycles_used );
  proc_current->cycles_started = 0;
  // unsigned long long = 16 bytes, e queremos ignorar ele, por isso "20" e não "4"
  __asm__ volatile(
      "mov 20(%%esp), %%eax"
      : "=A" (proc_current->registers.eip)
      :
      : "%eax"
      );
  __asm__ volatile(
      "mov 16(%%esp), %%eax"
      : "=A" (proc_current->registers.esp)
      :
      : "%eax"
      );
  // nós iremos usar lazy FPU context switch.
  Process* next_process = 0; // precisa pegar o próximo processo na lista
  __asm__ volatile(
      "mov %0, %%cr3"
      : "=A" (next_process->pti)
      // cr3 = pti next proc
      )
}
