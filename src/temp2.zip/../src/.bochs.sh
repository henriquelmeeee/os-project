bochs -f bochsrc.txt -q
