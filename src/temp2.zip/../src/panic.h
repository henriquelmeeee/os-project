void panic(unsigned int id, char* msg, unsigned long rip);
