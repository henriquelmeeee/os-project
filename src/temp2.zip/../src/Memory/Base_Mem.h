#ifndef BASE_MEM
#define BASE_MEM

#include "../Utils/Base.h"
#include "Heap/Heap.h"
namespace Memory{

// Flags:
// present,writeable,user_access,write_through,cache_disabled,accessed,ignored,size,ignored,page_ppn,reserved,ignored,execution_disabled
// pml4 = size sempre 0

struct PageFlags {
    u64 present:1;
    u64 writeable:1;
    u64 user_access:1;
    u64 write_through:1;
    u64 cache_disabled:1;
    u64 accessed:1;
    u64 ignored_3:1;
    u64 size:1;
    u64 ignored_2:4;
    u64 page_ppn:28; // or whatever the size should be
    u64 reserved_1:12;
    u64 ignored_1:11;
    u64 execution_disabled:1;
} __attribute__((packed));


union PageEntry {
  u64 flags; // todos os bits
  PageFlags flag_bits; // bit a bit
} __attribute__((packed));

template <typename V>
class Vector {
  private:
    V* chunk;
    u32 capacity;
    u32 last_element_index;
    char buf[128];
  public:
    Vector() {
      this->chunk = (V*) kmalloc(sizeof(V)*32);
      this->capacity = 32;
      this->last_element_index = 0;
      dbg("Vector::constructor-> novo vetor  construído\n");
    }

    V& operator[](u32 index) {
      if(index >= this->capacity-1) {
        dbg("Vector::operator[]-> fora da capacidade (index=");
        itos(index, this->buf);
        dbg(buf);
        dbg(")\n");
        do {
          V* new_chunk = (V*) kmalloc((capacity+32)*sizeof(V));
          for(int i = 0; i<this->capacity; i++) {
            //Utils::kmemcpy(new_chunk[i], this->chunk[i], sizeof(V));
          }
          kfree(this->chunk);
          this->chunk = new_chunk;
          this->capacity += 32;
        } while(index>=this->capacity);
      }
      //if(index>last_element_index) {
        //last_element_index = index+1;
      //}
      return this->chunk[index];
    };

    bool append(V value) {
      // TODO checar this->capacity
      //this->chunk+(last_element_index*sizeof(V)) = value;
      ++last_element_index;
      return true;
    }
};

}
#endif
