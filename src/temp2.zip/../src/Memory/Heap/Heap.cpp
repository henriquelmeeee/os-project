#include "../../Utils/Base.h"
#include "../../panic.h"
#define HEADER_SIZE 8

#define HEAP_BASE_ADDRESS (unsigned long) 500000000// 500MB
#define HEAP_MAX_ADDRESS (unsigned long) 1000000000 // 1GB

#define ALLIGNED_HEAP_BASE_ADDRESS (unsigned long) 100000000
#define ALLIGNED_HEAP_MAX_ADDRESS (unsigned long) 500000000

struct Chunk {
  u32 size; // 4 bytes
  char exists; // se não existir, então chegamos no topo da última chunk; quinto byte
  bool freed; // sexto byte
  char a; // sétimo byte
  char b; // oitavo byte
};

u64 number_of_chunks = 0;

void inline append_chunk(struct Chunk* addr) {
  //CHUNKS[number_of_chunks] = addr;
}

char itos_buffer[32];

// TODO FIXME fazer esse alligned ai
extern "C" void* kmalloc_alligned(unsigned int size) {
  while(( (size+8) % PAGE_SIZE) != 0) {
    ++size;
  }

  char* addr = (char*) ((unsigned long)ALLIGNED_HEAP_BASE_ADDRESS);
  struct Chunk* chunk_found;
  while(true) {
    struct Chunk* addr_buffer = (struct Chunk*) addr;
    if(( (unsigned long)addr_buffer>=ALLIGNED_HEAP_MAX_ADDRESS) || ((unsigned long)addr_buffer)+size>=ALLIGNED_HEAP_MAX_ADDRESS ) {
      throw_panic(0, "Alligned Heap overflow detected");
    }

    break;
  }
  return (void*)0;
}

extern "C" void* kmalloc(unsigned int size) {
  if(size > (TOTAL_RAM - mem_usage)) {
    return (void*)0;
  }
  // TODO talvez o certo seja iterar sobre cada chunk através de HEAP_BASE_ADDR
  // como cada chunk tem um header com informações, podemos achar um espaço disponível
  // baseado nisso
  // podemos usar 8 bytes no inicio para informação
  // 4 para o tamanho da chunk (não inclui os 8 bytes do header)
  // com o tamanho podemos chegar até a próxima chunk
  // os próximos 4 bytes do header seriam para flags
  // tipo se aquela chunk está disponível ou não
  char* addr = (char*)((unsigned long)HEAP_BASE_ADDRESS);
  struct Chunk* chunk_found;
  while(true) {
    struct Chunk* addr_buffer = (struct Chunk*)addr;
    if(( (unsigned long)addr_buffer>=HEAP_MAX_ADDRESS) || ((unsigned long)addr_buffer)+size>=HEAP_MAX_ADDRESS) {
          throw_panic(0, "Heap overflow detected"); // TODO heap region-based
    }
    if(addr_buffer->exists == 0) { // Caso não haja chunk aqui (byte 4 começando do zero)
      addr_buffer->exists = 1;
      addr_buffer->size = size;
      addr_buffer->freed = 0;
      chunk_found = (struct Chunk*)((unsigned long)addr_buffer);
      mem_usage+=size+8;
      break;
    } else {
      if((addr_buffer->freed) && (addr_buffer->size)>=size) { // TODO será q não precisa considerar o HEADER_SIZE?
        chunk_found = addr_buffer;
        addr_buffer->freed = 0;
        break;
      }
      addr+=addr_buffer->size+HEADER_SIZE;
    }
  }

  ++number_of_chunks;
  dbg("kmalloc()-> Nova chunk criada\n");
  dbg("kmalloc()-> Tamanho: ");
  itos((unsigned long)size, itos_buffer);
  dbg(itos_buffer);
  dbg(" (");
  itos((unsigned long)size+HEADER_SIZE, itos_buffer);
  dbg(itos_buffer);
  dbg(" se considerarmos o cabeçalho)");
  itos((unsigned long)addr, itos_buffer);
  dbgl;
  dbg("kmalloc()-> Endereço base: ");
  dbg(itos_buffer);
  dbgl;
  //return (void*)(addr + 8);
  return addr+HEADER_SIZE;
}

struct Chunk* kfind_chunk_by_size(u32 size) {
  for(struct Chunk* addr = (struct Chunk*)HEAP_BASE_ADDRESS;;) {
    if(!(addr->exists))
      dbg("kfind_chunk_by_size()-> Nenhuma chunk encontrada\n");
      break;

    if(addr->size == size) {
      dbg("kfind_chunk_by_size()-> Chunk encontrada\n");
      return addr;
    }

    addr+=addr->size;
    addr+=8;
  }
  return (struct Chunk*)0;
}

bool kfree(void* chunk_addr) {
  struct Chunk* chunk = (struct Chunk*) chunk_addr;
  chunk-=HEADER_SIZE;
  if(!(chunk->exists)) {
    dbg("kfree()-> Chunk inválida\n");
    return false;
  } else {
    itos((unsigned long)chunk, itos_buffer);
    dbg("kfree()-> Chunk ");
    dbg(itos_buffer);
    dbg(" liberada\n");
    chunk->freed = true;
    mem_usage-=(chunk->size-HEADER_SIZE);
    return true;
  }
}
