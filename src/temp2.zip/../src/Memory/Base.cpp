#include "../Utils/Base.h"
#include "Heap/Heap.h"
namespace Memory {
// Cada chunk de vetores simples poderão guardar 32 elementos

/*
template <typename V>
class SimpleVector {
  private:
    V* chunks[16];
    u64 last_index;
    i16 actual_element;
  public:
    SimpleVector() {
      this->last_index = 0;
      this->chunks[0] = (V*) kmalloc(sizeof(V)*32);
      this->actual_element = -1;
    };

    bool operator[] (i32 index) {
      
    };

    bool append_to_last(V value) {
      if(actual_element == 32 && last_index == 15)
        return false;
      if(actual_element == 32) {
        ++last_index;
        actual_element = 0;
        // TODO alloc new chunk
      } else {
        ++actual_element;
      }

      *(chunks[last_index])+actual_element*sizeof(V) = value;
      return true;
    }
};
*/


}
