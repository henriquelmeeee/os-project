qemu-system-x86_64 -drive file=../Build/disk.img,format=raw -vga std -d cpu_reset,int -m 1024 -serial stdio -enable-kvm
#sh bochs.sh # use boch?
#qemu-system-x86_64 -s -S -drive file=../Build/disk.img,format=raw -vga std -m 1024 -serial stdio -enable-kvm
