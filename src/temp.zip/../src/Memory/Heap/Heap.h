//#pragma once
#ifndef HEAP_H
#define HEAP_H
struct Chunk {
  unsigned int size;
  char freed;
  struct Chunk* next_chunk;
};

extern unsigned long number_of_chunks;

void inline append_chunk(struct Chunk* addr);

extern "C" void* kmalloc(unsigned int size, bool alligned = false);

signed int kfind_chunk_by_addr(struct Chunk* chunk_addr);

bool kfree(void* chunk_addr);
#endif
