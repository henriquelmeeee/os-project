#ifndef FS_H
#define FS_H
namespace FS {
  bool map_files_on_boot();
}
#endif
