extern "C" void kmain();
#define KERNEL_SIZE 26112
// Drivers:
//#include "Drivers/Keyboard.h"

#include "Drivers/VIDEO/preload.h"
#include "Drivers/Disk.h"
#include "Drivers/Mouse.h"

#include "Filesystem/Filesystem.h"

#include "DefaultConfig.h"
#include "Utils/Base.h"
#include "Utils/Errors.h"

#include "Memory/Base_Mem.h"
#include "Memory/Heap/Heap.h"

#include "Tasks/Process.h"
#include "panic.h"

// Interrupções:
#include "Interruptions/preload.h"
#include "Drivers/Keyboard.h"


unsigned long long mem_usage = 0;

extern "C" void kentrypoint() {kmain();}

volatile void sleep(unsigned long long ticks) {
  for(unsigned long long i = 0; i<ticks; i++) {for (volatile int j = 0; j<1000000; j++){}}
}

struct HardwareInformation {
  unsigned ram;
};

// Bootloader carrega a informação da quantidade de RAM no endereço "15000"
// então nós devemos recuperar o valor nesse endereço 

unsigned long long TOTAL_RAM = 0;

unsigned long *pages_in_use;

// IDT -> configurações gerais

struct IDT_entry { // Interruption Gate
  u16 base_lo; // endereço mais baixo da ISR (deslocamento baseado no segmento)
  u16 sel; // seletor de segmento do kernel
  unsigned char always0;
  unsigned char flags;
  u16 base_mid;
  u32 base_hi;
  u32 reserved; // FIXME u32 or unsigned char or char?
} __attribute__((packed));

struct IDT_ptr {
  unsigned short limit;
  struct IDT_entry* base;
} __attribute__((packed));

struct IDT_entry IDT_entries[256]; // aloca elementos para IDT

void halt() {
  __asm__ volatile(
      "hlt"
      );
}

void disable_irq(int irq) {
    unsigned short port;
    unsigned char value;

    if(irq < 8) {
        port = 0x21;
    } else {
        port = 0xA1;
        irq -= 8;
    }
    value = inb(port) | (1 << irq);
    outb(port, value);        
}

namespace Initialize {
  namespace FirstStage {
  bool init_idt_entries() {
  for(int i = 0; i<sizeof(IDT_entries) / sizeof(IDT_entries[0]); i++) {
    #ifndef IDT_entries_amount
      #define IDT_entries_amount 256
    #endif

    if(i+1 > IDT_entries_amount)
      break;
    

    switch (i) {
      case 16: { // FPU-x87 error
        u64 fpu_err_addr = reinterpret_cast<u64>(i_fpuerr);
        IDT_entries[i] = (struct IDT_entry){
          .base_lo = static_cast<u16>(fpu_err_addr & (u64) 0xFFFF),
          .sel = (unsigned short)0x08,
          .always0 = (char)0, // interrupt stack table
          .flags = (unsigned char)0x8E,
          .base_mid = static_cast<u16>((fpu_err_addr>>16) & (u64)0xFFFF),
          .base_hi = static_cast<u32>(fpu_err_addr>>32),
          .reserved = (u32)0, 
        };
      };
      case 502: { //14+32 disco      
        break;
      };
      case 501: {//15+32 disco também
        break;
      }
      case 500:{ // 12+32 IRQ12 = moue
        u64 mouse_interrupt_addr = reinterpret_cast<u64>(Drivers::Mouse::mouse_interrupt);
        IDT_entries[i] = (struct IDT_entry){
          .base_lo = static_cast<u16>(mouse_interrupt_addr & (u64) 0xFFFF),
          .sel = 0x08,
          .always0 = 0,
          .flags = 0x8E,
          .base_mid = static_cast<u16>((mouse_interrupt_addr>>16) & (u64)0xFFFF),
          .base_hi = static_cast<u32>(mouse_interrupt_addr>>32),
          .reserved = (u32)0,
        };
      };
      case 33:{ // 33 IRQ1 - Teclado
        u64 keyboard_interrupt_addr = reinterpret_cast<u64>(Drivers::Keyboard::keyboard_interrupt_key);
        IDT_entries[i] = (struct IDT_entry){
          .base_lo = static_cast<u16>(keyboard_interrupt_addr & (u64) 0xFFFF),
          .sel = 0x08,
          .always0 = 0,
          .flags = 0x8E,
          .base_mid = static_cast<u16>((keyboard_interrupt_addr>>16) & (u64)0xFFFF),
          .base_hi = static_cast<u32>(keyboard_interrupt_addr>>32),
          .reserved = (u32)0,
        };
        break;}
      default:
        u64 i_spurious_addr = reinterpret_cast<u64>(i_spurious);
        IDT_entries[i] = (struct IDT_entry){
          .base_lo = static_cast<u16>(i_spurious_addr & (u64) 0xFFFF),
          .sel = 0x08,
          .always0 = 0,
          .flags = 0x8E,
          .base_mid = static_cast<u16>((i_spurious_addr>>16) & (u64)0xFFFF),
          .base_hi = static_cast<u32>(i_spurious_addr>>32),
          .reserved = (u32)0,
        };
        break;
    };
  }
  return true;
}

    bool init_idt_ptr(u16 size) {
      // Inicializa os descritores da IDT
      volatile struct {
        u16 length;
        u64 base;
      } __attribute__((packed)) IDTR = { size, (u64)IDT_entries};
      __asm__ volatile (
          "lidt %0"
          :
          : "m" (IDTR)
          );
      dbg("Initialize::FirstStage::init_idt_ptr()-> finalizado\n");
      return true;
    }
    
    bool init_pages_in_use() { // aloca uma chunk para a array de páginas em uso na Heap
      pages_in_use = (unsigned long*)kmalloc(PAGE_SIZE);
      return true;
    }

    bool init_idt_config() {
      #define PIC1_COMMAND 0x20
      #define PIC1_DATA    0x21
      #define PIC2_COMMAND 0xA0
      #define PIC2_DATA    0xA1
      #define PIC_EOI      0x20
      #define PIC_INIT     0x11
      #define PIC_ICW4     0x01

      outb(PIC1_COMMAND, PIC_INIT);
      outb(PIC2_COMMAND, PIC_INIT);
    
      outb(PIC1_DATA, 32);   // Definir o vetor de interrupção inicial do PIC1 para 32 (0x20)
      outb(PIC1_DATA, 4);    // Definir PIC2 para ser acionado pela linha IRQ2 do PIC1
      outb(PIC1_DATA, PIC_ICW4);

      outb(PIC2_DATA, 40);   // Definir o vetor de interrupção inicial do PIC2 para 40 (0x28)
      outb(PIC2_DATA, 2);    // Definir PIC2 para ser acionado pela linha IRQ2 do PIC1
      outb(PIC2_DATA, PIC_ICW4);
      outb(PIC1_COMMAND, PIC_EOI);
      return true;
    }
    bool init() {
      TRY(init_idt_entries(), ErrorType{CRITICAL}, "An error occurred while trying to initialize the IDT");
      TRY(init_idt_ptr(sizeof(IDT_entries)), ErrorType{CRITICAL}, "An error occurred while trying to initialize the IDT (lidt)");
      TRY(init_idt_config(), ErrorType{CRITICAL}, "An error occurred while trying to configure the IDT");
      //TRY(init_pages_in_use(), ErrorType{CRITICAL});

      return true;
    }
  }
  namespace SecondStage {
    bool init_procs() {
      if(!(Process::init())) 
        return false;
      if(!(Process::CreateProcess("initd", 0)))
    return true;
        return false;
      return true;
    }
    bool init() {
      return true;
      //TRY(FS::map_files_on_boot(), ErrorType{CRITICAL}, "Critical file \"initd\" not found");
      // se não houver nenhum arquivo, então não há nem mesmo o processo "init"
      TRY(init_procs(), ErrorType{CRITICAL}, "Unable to initialize task system");
      return true;
    }
  }
}

#define fo (char)15

int a_bitmap[15][2] = {
  {5, 5},
  {6, 5},
  {7, 5},
  {8, 5},
  {8, 6},
  {8, 7},
  {8, 8},
  {8, 9},
  {5, 6},
  {5, 7},
  {5, 8},
  {5, 9},
  {6, 7},
  {7, 7},
  {8, 7},
};

#define PORT (char)0x3f8 /* COM1 register, for control */

void init_serial() {
   outb(PORT + 1, (char)0x00);    // Disable all interrupts
   outb(PORT + 3, (char)0x80);    // Enable DLAB (set baud rate divisor)
   outb(PORT + 0, (char)0x03);    // Set divisor to 3 (lo byte) 38400 baud
   outb(PORT + 1, (char)0x00);    //                  (hi byte)
   outb(PORT + 3, (char)0x03);    // 8 bits, no parity, one stop bit
   outb(PORT + 2, (char)0xC7);    // Enable FIFO, clear them, with 14-byte threshold
   outb(PORT + 4, (char)0x0B);    // IRQs enabled, RTS/DSR set
}

char itos_b[20];

extern "C" void kmain() {
  CLI;
  mem_usage+=KERNEL_SIZE;
  TOTAL_RAM = 1 GB;
  init_serial();
  char fodase[32];
  dbg("kmain()-> Kernel iniciando\n");


  #ifndef GRAPHICAL_MODE
    dbg("kmain()-> Modo de texto está habilitado\n");
    char* txtaddr = (char*)0xB8000;
    Text::text_clear();
    Text::Write("Kernel loaded");
    dbg("kmain()-> AVISO Modo de texto habilitado\n");
    //memcpy(txtaddr, const_cast<char*>("Kernel Loaded\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\1"));
  #else
    dbg("kmain() -> Modo gráfico está habilitado\n");
    //struct VBEInfo* vbei = ( (struct VBEInfo*) ((unsigned long)0x5000) ); A ESTRUTURA TÁ ERRADA
    //char buffer_fodase[512];
    //itos(vbei->physbase, buffer_fodase);
    //dbg("endereço video: ");
    //dbg(buffer_fodase);
    //dbg("\n");


    //Graphics::clear_video((char)0);
    Graphics::draw_cursor();
    //Graphics::print_string(const_cast<char*>("Loaded Kernel"));
  #endif
  
  TRY(Initialize::FirstStage::init(), ErrorType{CRITICAL}, "FirstStage init failed");
  //TRY(Initialize::SecondStage::init(), ErrorType{CRITICAL}, "SecondStage init failed");
  //Text::NewLine();
  //Text::Write("Started processes");
  //
  //
  //KEYBOARD TEMPORARY INITIALIZE
#define PS2_COMMAND_PORT 0x64
#define PS2_DATA 0x60
#define ENABLE_KEYBOARD 0xAE
#define RESET_KEYBOARD 0xFF
  //outb(PS2_COMMAND_PORT, ENABLE_KEYBOARD); //
  //outb(PS2_DATA, RESET_KEYBOARD); //
  //outb(PS2_DATA, ENABLE_KEYBOARD);
  //inb(PS2_DATA); inb(PS2_DATA);
  dbg("entrando no while true\n");
  STI;
  while(true){dbg("voltando");halt();}

  //Process::start_shell();
  
  // Agora, o programa 'shell' está na lista de processos
  // Registradores como RSP e RIP estão setados para o padrão (RSP para endereço da stack padrão, RIP para a func main)
  // O shell estará carregado a partir do setor 400 por padrão. TODO carregar no bootloader

  //Process::force_context_switch(); // É aqui que o Kernel começará a executar o Shell



  //STI;*/
}
