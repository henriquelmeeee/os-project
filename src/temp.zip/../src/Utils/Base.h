#ifndef BASE_H
#define BASE_H
#define CLI __asm__("cli")
#define STI __asm__("sti")

#define NO_CALLER_SAVED_REGISTERS __attribute__((no_caller_saved_registers))

#define u64 unsigned long
#define u32 unsigned int
#define u128 unsigned long long
#define i64 signed long
#define i32 signed int
#define u16 unsigned short
#define u8 unsigned char
#define i16 signed short
#define i8 signed char

#define KB *1000
#define MB *1000000
#define GB *1000000000
#define TB *1000000000000

struct VBEInfo {
  u16 flags;
  unsigned char windowA, windowB;
  u16 granularity;
  u16 windowSize;
  u16 segmentA, segmentB;
  u32 winFuncPtr;
  u16 pitch;

  u16 width, height;
  
  unsigned char wChar, yChar, planes, bpp, banks; // bpp = bits por pixel
  unsigned char memoryModel, bankSize, imagePages;
  unsigned char reserved0;

  unsigned char readMask, redPosition;
  unsigned char greenMask, greenPosition;
  unsigned char blueMask, bluePosition;
  unsigned char reservedMask, reservedPosition;
  unsigned char directColorAttributes;

  u32 physbase;
  u32 reserved1;
  u16 reserved2;
};

extern unsigned long long TOTAL_RAM;

struct P {
  u64 Present;
  u64 Writable;
  u64 User;
  u64 WriteThrough;
  u64 CacheDisabled;
  u64 Accessed;
  u64 Dirty;
  u64 PAT;
  u64 Global;
  u64 Ignored : 3;
  u64 Frame : 40;
  u64 Available : 11;
  u64 NX;
} __attribute__((packed));

struct PT {
  struct P Pe[512];
};

struct PD {
  struct PT* PTe[512];
};

struct PDPT {
  struct PD* PDe[512];
};

struct PML4 {
  struct PDPT* PDPTe;
};

#define PAGE_SIZE 2000000

extern unsigned long long mem_usage;

extern "C" void *memcpy(void* dest, const void* src, int size);

#define outb(port, val) \
  __asm__ volatile("outb %0, %1" : : "a"((char)val), "dN"((short)port))

#define inb(port) ({\
  unsigned char result; \
  __asm__ volatile("inb %%dx, %%al" : "=a" (result) : "d" ((short)port)); result; })

#define dbg(x) do { \
  const char* str = (x); \
  for(int i = 0; str[i] != '\0'; ++i) \
    outb(0x3F8, str[i]); \
} while (0)

#define dbgl dbg("\n")
enum ErrorType {
  CRITICAL,
  IRRELEVANT,
};

#define throw_panic(err_code, msg) \
  unsigned long rip; \
  __asm__ volatile("leaq (%%rip), %0" : "=r" (rip)); \
  panic((unsigned int)0, const_cast<char*>(msg), rip); \

#define TRY(condition, error_type, msg) \
  if(!(condition)) { \
    if(error_type == 0) { \
      unsigned long rip; \
      __asm__ volatile("leaq (%%rip), %0" : "=r" (rip)); \
      panic((unsigned int)0, const_cast<char*>(msg), rip);\
    } \
  } \

namespace Utils {


template <typename T>
void append_to_array(T* array, T value, unsigned long size);

template <typename T>
bool kmemcpy(T* dest, T* orig, unsigned long size) {
  dest = (char*)dest;
  orig = (char*)orig;
  for(int i = 0; i<size; i++) {
    dest[0] = orig[0];
  }
  return true;
}
}
bool itos(long value, char* to_ret);
bool itoh(long value, char* to_ret);

#endif
