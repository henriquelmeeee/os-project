/*


*/

#define EUNK 0
#define EUNK_STR "Unknown error"

#define ENORAM 1
#define ENORAM_STR "Not enough space in RAM"

#define EIO 2
#define EIO_STR "I/O error"

#define ESEGFAULT 3
#define ESEGFAULT_STR "Segmentation Fault: invalid page"
